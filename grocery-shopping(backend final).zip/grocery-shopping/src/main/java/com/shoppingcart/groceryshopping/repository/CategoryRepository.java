package com.shoppingcart.groceryshopping.repository;


import org.springframework.data.repository.CrudRepository;

import com.shoppingcart.groceryshopping.model.*;

public interface CategoryRepository extends CrudRepository<Category, Integer>{

}
