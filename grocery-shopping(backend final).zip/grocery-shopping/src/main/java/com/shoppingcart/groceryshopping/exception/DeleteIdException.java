package com.shoppingcart.groceryshopping.exception;

public class DeleteIdException extends RuntimeException{
	
	public DeleteIdException(String msg) {
		super(msg);
	}

}
