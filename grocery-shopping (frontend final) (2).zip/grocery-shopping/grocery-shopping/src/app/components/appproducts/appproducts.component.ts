import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appproducts',
  templateUrl: './appproducts.component.html',
  styleUrls: ['./appproducts.component.css']
})
export class AppproductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
