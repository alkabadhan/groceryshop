package com.shoppingcart.groceryshopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryShoppingApplicationTests {

	@Test
	void contextLoads() {
	}

}
