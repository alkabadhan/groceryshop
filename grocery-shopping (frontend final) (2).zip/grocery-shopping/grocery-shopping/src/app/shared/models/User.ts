

export class User{
  [x: string]: any;
  //[x: string]: any;
    id: number;
    firstName: string;
    lastName: string;
    emailId: string;
    mobileNumber: String;
    userName: string;
    password: string;

   constructor( ){  }
}

